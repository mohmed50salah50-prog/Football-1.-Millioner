/* مليونير كرة القدم — منطق اللعبة */
(function () {
"use strict";
const $ = (s, r = document) => r.querySelector(s);
const CFG = window.CFG || {};
const LADDER = [100,200,300,500,1000,2000,4000,8000,16000,32000,64000,125000,250000,500000,1000000];
const SAFE = [4, 9]; // بعد السؤال 5 و 10
const RANKS = [[0,"مبتدئ"],[1000,"هاوي"],[10000,"لاعب"],[50000,"محترف"],[200000,"نجم"],[1000000,"أسطورة اللعبة"]];
const DAILY_GEMS = [50,75,100,150,200,300,500];
const LL = {
  fifty: { ic: "½", nm: "50:50", price: 40 },
  aud:   { ic: "👥", nm: "الجمهور", price: 40 },
  call:  { ic: "📞", nm: "صديق", price: 40 },
  skip:  { ic: "⏭", nm: "تخطي", price: 60 }
};
const LET = ["أ","ب","ج","د"];

/* ---------- أدوات ---------- */
const today = () => { const d = new Date(); return d.getFullYear() + "-" + (d.getMonth()+1) + "-" + d.getDate(); };
const yesterday = () => { const d = new Date(Date.now() - 864e5); return d.getFullYear() + "-" + (d.getMonth()+1) + "-" + d.getDate(); };
const fmt = n => n >= 1e6 ? "مليون" : n >= 1000 ? (n/1000) + " ألف" : String(n);
const num = n => Number(n).toLocaleString("en-US");
const shuffle = a => { a = a.slice(); for (let i = a.length-1; i > 0; i--) { const j = Math.floor(Math.random()*(i+1)); [a[i],a[j]] = [a[j],a[i]]; } return a; };
const esc = s => String(s).replace(/[&<>"]/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
const lsGet = (k, d) => { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : d; } catch (e) { return d; } };
const lsSet = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} };
const hashStr = s => { let h = 5381; for (let i = 0; i < s.length; i++) h = ((h << 5) + h + s.charCodeAt(i)) | 0; return (h >>> 0).toString(36); };
const qid = r => hashStr(r[0]);
async function sha(s) {
  try { const b = await crypto.subtle.digest("SHA-256", new TextEncoder().encode("fm:" + s));
    return Array.from(new Uint8Array(b)).map(x => x.toString(16).padStart(2,"0")).join(""); }
  catch (e) { return "h" + hashStr("fm:" + s); }
}
const rankOf = p => { let r = RANKS[0][1]; RANKS.forEach(x => { if (p >= x[0]) r = x[1]; }); return r; };
const firebaseOn = () => CFG.FIREBASE && CFG.FIREBASE.apiKey;

/* ---------- صوت واهتزاز ---------- */
let AC;
function beep(f, d, type, when) {
  if (!S || !S.set.sound) return;
  try {
    AC = AC || new (window.AudioContext || window.webkitAudioContext)();
    const o = AC.createOscillator(), g = AC.createGain();
    o.type = type || "sine"; o.frequency.value = f;
    const t = AC.currentTime + (when || 0);
    g.gain.setValueAtTime(.0001, t); g.gain.exponentialRampToValueAtTime(.18, t + .02);
    g.gain.exponentialRampToValueAtTime(.0001, t + d);
    o.connect(g); g.connect(AC.destination); o.start(t); o.stop(t + d + .02);
  } catch (e) {}
}
const sfx = {
  tap: () => beep(520, .06, "triangle"),
  ok: () => { beep(660,.12,"triangle"); beep(880,.12,"triangle",.12); beep(1175,.2,"triangle",.24); },
  no: () => { beep(220,.25,"sawtooth"); beep(150,.35,"sawtooth",.2); },
  tick: () => beep(900, .04, "square"),
  win: () => [523,659,784,1047,1319].forEach((f,i) => beep(f,.18,"triangle",i*.12))
};
const vib = ms => { try { if (S && S.set.vibrate && navigator.vibrate) navigator.vibrate(ms); } catch (e) {} };

/* ---------- الحفظ ---------- */
let SES = lsGet("fm_session", null);
let S = null;
const defData = () => ({
  gems: 200, points: 0, xp: 0, lvl: 1,
  stats: { games: 0, correct: 0, wrong: 0, best: 0, millions: 0, streak: 0, bestStreak: 0, dailyDone: 0 },
  daily: { last: "", streak: 0, claimedToday: false },
  mis: { date: "", correct: 0, c10: false, c25: false },
  dc: "", inv: { fifty: 0, aud: 0, call: 0, skip: 0 },
  seen: [], recent: [], hist: [], ach: {}, set: { sound: true, vibrate: true }
});
function loadData() {
  if (!SES) return;
  S = Object.assign(defData(), lsGet("fm_data_" + SES.id, {}));
  S.set = Object.assign({ sound: true, vibrate: true }, S.set);
  S.stats = Object.assign(defData().stats, S.stats);
  S.inv = Object.assign(defData().inv, S.inv);
  S.lvl = clamp(S.lvl || 1, 1, 4);
  if (S.mis.date !== today()) S.mis = { date: today(), correct: 0, c10: false, c25: false };
  if (S.daily.last !== today()) S.daily.claimedToday = false;
}
const save = () => { if (SES && S) lsSet("fm_data_" + SES.id, S); };

/* ---------- الأسئلة: ذكاء اصطناعي (أونلاين) + 200 سؤال محفوظ (أوفلاين) ---------- */
const BUNDLED = window.BUNDLED_QUESTIONS || [];
const AICFG = CFG.AI || {};
const CACHE_MAX = 200;
let REMOTE = lsGet("fm_remote", []);
let CACHE = lsGet("fm_cache", []);          // آخر/أهم 200 سؤال محفوظين للعب بدون نت
const BUF = {};                              // أسئلة جاهزة مسبقاً لكل مستوى صعوبة
const inflight = {};
let aiDownUntil = 0, filling = false, fillRuns = 0;
const online = () => navigator.onLine !== false;
const aiOn = () => AICFG.ENABLED !== false && AICFG.ENDPOINT;
const remoteConfigured = () => CFG.QUESTIONS_URL && !/USERNAME|REPO/.test(CFG.QUESTIONS_URL);
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const lvOf = d => d <= 3 ? 1 : d <= 7 ? 2 : 3;          // تحويل صعوبة 1-10 لمستوى 1-3 للأسئلة المدمجة
const rawD = r => r[6] || (r[5] * 3 - 1);
function validQ(r) { return Array.isArray(r) && r.length >= 6 && r.slice(0,5).every(x => typeof x === "string" && x.trim()) && new Set(r.slice(1,5).map(x => x.trim())).size === 4; }
async function refreshQuestions() {
  if (!online() || !remoteConfigured()) return false;
  try {
    const ctl = new AbortController(); const to = setTimeout(() => ctl.abort(), 8000);
    const res = await fetch(CFG.QUESTIONS_URL + "?t=" + Date.now(), { signal: ctl.signal, cache: "no-store" });
    clearTimeout(to);
    if (!res.ok) return false;
    const data = await res.json();
    const arr = (Array.isArray(data) ? data : data.questions || []).filter(validQ);
    if (arr.length >= 10) { REMOTE = arr; lsSet("fm_remote", arr); return true; }
  } catch (e) {}
  return false;
}
function poolAll() {
  const m = new Map();
  BUNDLED.concat(REMOTE).forEach(r => { if (validQ(r)) m.set(qid(r), r); });
  return Array.from(m.values());
}

/* --- الكاش (200 سؤال) --- */
function cacheSave() { lsSet("fm_cache", CACHE); }
function cacheAdd(r, d, fill) {
  if (!validQ(r)) return;
  const id = qid(r), had = CACHE.findIndex(x => qid(x) === id);
  if (had >= 0) { if (fill) return; CACHE.splice(had, 1); }
  if (CACHE.length >= CACHE_MAX) {
    const bi = CACHE.findIndex(x => x[7] === "b");       // نشيل المدمجة المحشوّة الأول
    if (bi >= 0) CACHE.splice(bi, 1); else if (fill) return; else CACHE.shift();
  }
  CACHE.push([r[0], r[1], r[2], r[3], r[4], r[5] || lvOf(d), d || rawD(r)]);
  cacheSave();
}
function padCache() {            // نضمن إن فيه 200 سؤال جاهزين حتى لو أول مرة وبدون نت
  if (CACHE.length >= CACHE_MAX) return;
  const have = new Set(CACHE.map(qid));
  const extra = shuffle(poolAll()).filter(r => !have.has(qid(r))).slice(0, CACHE_MAX - CACHE.length).map(r => [r[0], r[1], r[2], r[3], r[4], r[5], rawD(r), "b"]);
  CACHE = extra.concat(CACHE); cacheSave();
}

/* --- توليد الأسئلة بالذكاء الاصطناعي --- */
const TOPICS = ["كأس العالم","دوري أبطال أوروبا","الدوري الإنجليزي الممتاز","الدوري الإسباني","الدوري الإيطالي","الدوري الألماني","الدوري المصري","كأس الأمم الأفريقية","الأهلي والزمالك","المنتخب المصري","اللاعبون العرب","صفقات الانتقالات","الكرة الذهبية","الهدّافون التاريخيون","المدربون","الملاعب والأندية الكبرى","الأرقام القياسية","كأس أمم أوروبا وكوبا أمريكا","أساطير الكرة","قوانين اللعبة","الدوري الفرنسي والبرتغالي","نهائيات البطولات الكبرى","كأس العالم للأندية"];
const DESC = d => d <= 2 ? "very easy (anyone who watches football knows it)" : d <= 4 ? "easy-to-medium (casual fan)" : d <= 6 ? "medium-hard (dedicated fan)" : d <= 8 ? "hard (only serious fans know it)" : "extremely hard (football historians / statisticians only)";
async function aiAsk(d, n) {
  const topic = TOPICS[Math.floor(Math.random() * TOPICS.length)];
  const avoid = (S && S.recent ? S.recent.slice(-20) : []).map(r => r[0].slice(0, 70)).join(" | ");
  const prompt = `Write ${n} NEW multiple-choice trivia questions in Arabic about MEN'S football only.\nDifficulty: ${d}/10 — ${DESC(d)}. Main topic: ${topic} (you may vary a little).\nRules: each question has exactly ONE undeniably correct answer; use only facts you are 100% sure of; no questions about the future or anything dated/uncertain; wrong answers must be plausible but clearly wrong; keep every answer under 40 characters; write in simple Arabic; do not repeat these already-asked questions: ${avoid || "none"}.\nOutput ONLY a JSON array (no markdown, no explanation) where each item is: ["السؤال","الإجابة الصحيحة","خطأ 1","خطأ 2","خطأ 3"].`;
  const headers = { "Content-Type": "application/json" };
  if (AICFG.API_KEY) headers.Authorization = "Bearer " + AICFG.API_KEY;
  const ctl = new AbortController(); const to = setTimeout(() => ctl.abort(), 20000);
  try {
    const res = await fetch(AICFG.ENDPOINT, { method: "POST", headers, signal: ctl.signal, body: JSON.stringify({ model: AICFG.MODEL || "openai", seed: Math.floor(Math.random() * 1e9), temperature: 1, messages: [{ role: "system", content: "You are a precise football quiz writer. You answer with raw JSON only." }, { role: "user", content: prompt }] }) });
    if (!res.ok) throw new Error("http " + res.status);
    const j = await res.json();
    let txt = (j.choices && j.choices[0] && j.choices[0].message && j.choices[0].message.content) || (typeof j === "string" ? j : "");
    txt = String(txt).replace(/```json|```/g, "");
    const arr = JSON.parse(txt.slice(txt.indexOf("["), txt.lastIndexOf("]") + 1));
    const seen = new Set(S ? S.seen : []), out = [], ids = new Set();
    arr.forEach(it => {
      if (it && !Array.isArray(it) && typeof it === "object") it = [it.q || it.question, it.correct || it.answer, ...(it.wrong || [])];
      if (!Array.isArray(it)) return;
      it = it.slice(0, 5).map(x => String(x == null ? "" : x).trim());
      if (!validQ(it.concat([1])) || it[0].length < 8 || !/[\u0600-\u06FF]/.test(it[0]) || it.some(x => x.length > 70)) return;
      const r = [it[0], it[1], it[2], it[3], it[4], lvOf(d), d];
      const id = qid(r); if (seen.has(id) || ids.has(id)) return;
      ids.add(id); out.push(r);
    });
    if (!out.length) throw new Error("empty");
    return out;
  } finally { clearTimeout(to); }
}
function generate(d, n) {
  if (inflight[d]) return inflight[d];
  const p = (async () => {
    try { const qs = await aiAsk(d, n); (BUF[d] = BUF[d] || []).push(...qs); return qs.length; }
    catch (e) { aiDownUntil = Date.now() + 45000; return 0; }
    finally { delete inflight[d]; }
  })();
  return (inflight[d] = p);
}
function aiReady() { return online() && aiOn() && Date.now() >= aiDownUntil; }
function prefetch(d) { if (!aiReady()) return; [clamp(d + 1, 1, 10), d].forEach(x => { if (!(BUF[x] && BUF[x].length)) generate(x, 3); }); }
async function fillCache() {        // في الخلفية: نملّي الـ200 سؤال بأسئلة جديدة من الذكاء الاصطناعي
  if (filling || !aiReady() || !S) return;
  filling = true;
  try {
    const order = [2, 5, 8, 3, 6, 9, 4, 7, 10, 1];
    for (let k = 0; k < 8 && fillRuns < 40 && aiReady() && online(); k++, fillRuns++) {
      if (CACHE.filter(x => x[7] !== "b").length >= CACHE_MAX) break;
      const d = order[fillRuns % order.length];
      try { const qs = await aiAsk(d, 5); qs.forEach(r => cacheAdd(r, d, true)); } catch (e) { aiDownUntil = Date.now() + 45000; break; }
      await new Promise(r => setTimeout(r, 1500));
    }
  } finally { filling = false; }
}

/* --- اختيار السؤال --- */
function takeBuf(d) {
  const arr = BUF[d] || [];
  while (arr.length) { const r = arr.shift(); if (!S.seen.includes(qid(r)) && !G.usedIds.has(qid(r))) return r; }
  return null;
}
function pickPool(d) {            // أسئلة مدمجة/GitHub لم تظهر للاعب من قبل
  const lv = lvOf(d), pool = poolAll(), seen = new Set(S.seen);
  const free = r => !seen.has(qid(r)) && !G.usedIds.has(qid(r));
  let c = pool.filter(r => r[5] === lv && free(r));
  if (!c.length) c = pool.filter(r => Math.abs(r[5] - lv) <= 1 && free(r));
  return c.length ? c[Math.floor(Math.random() * c.length)] : null;
}
function pickCache(d) {           // أوفلاين: من الـ200 المحفوظين (بيتكرروا)
  if (!CACHE.length) padCache();
  let pool = CACHE.filter(r => !G.usedIds.has(qid(r)));
  if (!pool.length) { G.usedIds.clear(); pool = CACHE.slice(); }
  if (!pool.length) return null;
  pool.sort((x, y) => Math.abs(rawD(x) - d) - Math.abs(rawD(y) - d) + (Math.random() - .5) * 2.5);
  return pool[0];
}
function curD() {
  let d;
  if (G.mode === "cup") d = G.stD + G.rs - G.ws * .6;
  else d = S.lvl + (G.right - G.wrong) * .7;
  return clamp(Math.round(d), 1, 10);
}
async function fetchQuestion(g) {
  const d = curD(); g.d = d; g.maxD = Math.max(g.maxD || 0, d);
  let raw = null;
  if (online()) {
    raw = takeBuf(d);
    if (!raw && aiReady()) { await generate(d, g.mode === "speed" ? 4 : 3); if (G !== g) return null; raw = takeBuf(d); }
    if (!raw) raw = pickPool(d);
  }
  if (!raw) raw = pickCache(d);
  if (!raw) return null;
  g.usedIds.add(qid(raw));
  return norm(raw, d);
}
function norm(r, d) {
  const opts = shuffle([0,1,2,3]).map(i => ({ t: r[1 + i], ok: i === 0 }));
  return { raw: r, id: qid(r), q: r[0], opts, ans: opts.findIndex(o => o.ok), l: r[5], d: d || rawD(r) };
}
function markServed(q) {
  if (!online()) return;                      // أوفلاين: مفيش تسجيل، الأسئلة المحفوظة بتتكرر
  S.seen = S.seen.filter(x => x !== q.id); S.seen.push(q.id);
  if (S.seen.length > 5000) S.seen = S.seen.slice(-5000);
  S.recent = S.recent.filter(r => qid(r) !== q.id); S.recent.push(q.raw);
  if (S.recent.length > 100) S.recent = S.recent.slice(-100);
  cacheAdd(q.raw, q.d);
  save();
}

/* ---------- واجهة عامة ---------- */
let screen = "splash", timerId = null, G = null;
const app = $("#app");
function stopTimer() { if (timerId) { clearInterval(timerId); timerId = null; } }
function toast(m) { const t = $("#toast"); t.textContent = m; t.classList.remove("hidden"); clearTimeout(toast.h); toast.h = setTimeout(() => t.classList.add("hidden"), 2400); }
function modal(html) { const m = $("#modal"); m.innerHTML = '<div class="mbox">' + html + "</div>"; m.classList.remove("hidden"); }
function closeModal() { $("#modal").classList.add("hidden"); $("#modal").innerHTML = ""; }
function confetti() {
  const d = document.createElement("div"); d.className = "conf";
  const cols = ["#ffe58a","#f5b727","#38d4ff","#2f7bff","#22c55e","#fff"];
  for (let i = 0; i < 60; i++) { const e = document.createElement("i"); e.style.left = Math.random()*100 + "%"; e.style.background = cols[i % cols.length]; e.style.animationDuration = (1.8 + Math.random()*1.8) + "s"; e.style.animationDelay = Math.random()*.6 + "s"; d.appendChild(e); }
  document.body.appendChild(d); setTimeout(() => d.remove(), 4500);
}
function netBadge() { return online() ? '<span class="net on">● أونلاين</span>' : '<span class="net off">● أوفلاين</span>'; }

function header() {
  const name = SES ? SES.name : "";
  return `<div class="top">
    <button class="avatar" data-go="profile">👑</button>
    <div class="who"><b>${esc(name)}</b><small>★ ${rankOf(S.points)}</small></div>
    <div class="gems"><span>💎</span><span>${num(S.gems)}</span><button class="plus" data-go="rewards">+</button></div>
    <button class="ibtn" data-go="board">🏆</button>
    <button class="ibtn" data-go="settings">⚙</button>
  </div>`;
}
function nav(cur) {
  const it = [["home","🏠","الرئيسية"],["challenges","⚡","التحديات"],["arena","🌍","البطولات"],["board","🏆","نتائجي"],["profile","👤","حسابي"]];
  return '<div class="nav">' + it.map(x => `<button data-go="${x[0]}" class="${cur === x[0] ? "on" : ""}"><span>${x[1]}</span>${x[2]}</button>`).join("") + "</div>";
}
function go(name, p) { stopTimer(); closeModal(); screen = name; window.scrollTo(0, 0); (R[name] || R.home)(p); }

/* ---------- الشاشات ---------- */
const R = {};

R.splash = function () {
  app.innerHTML = '<div class="splash"><img src="icon.png" alt=""></div>';
  setTimeout(() => { loadData(); if (SES && S) { dailyLogin(); go("home"); } else go("login"); }, 1100);
};

/* تسجيل الدخول */
R.login = function (tab) {
  tab = tab || "in";
  app.innerHTML = `<div class="login">
    <img src="icon.png" alt="مليونير كرة القدم">
    <div class="tabs"><button data-tab="in" class="${tab==="in"?"on":""}">تسجيل الدخول</button><button data-tab="up" class="${tab==="up"?"on":""}">حساب جديد</button></div>
    ${tab==="up" ? '<input class="inp" id="nm" placeholder="الاسم في اللعبة" maxlength="20" autocomplete="nickname">' : ""}
    <input class="inp" id="em" type="email" placeholder="البريد الإلكتروني" dir="ltr" autocomplete="email">
    <input class="inp" id="pw" type="password" placeholder="كلمة السر (6 أحرف على الأقل)" dir="ltr" autocomplete="${tab==="up"?"new-password":"current-password"}">
    <div class="err" id="err"></div>
    <button class="btn" id="sub">${tab==="up" ? "إنشاء الحساب" : "دخول"}</button>
    ${tab==="in" && firebaseOn() ? '<button class="btn ghost" id="forgot" style="margin-top:8px">نسيت كلمة السر؟</button>' : ""}
    <div class="or">أو</div>
    <button class="btn sec" id="guest">👤 العب كضيف</button>
    <p class="mut" style="margin-top:14px">${netBadge()}</p>
  </div>`;
  app.querySelectorAll("[data-tab]").forEach(b => b.onclick = () => R.login(b.dataset.tab));
  $("#guest").onclick = () => { startSession({ id: "guest", name: "ضيف", guest: true }); };
  $("#sub").onclick = () => doAuth(tab);
  const f = $("#forgot"); if (f) f.onclick = forgot;
};
const authErr = c => ({ EMAIL_EXISTS: "الإيميل ده مسجل قبل كده", INVALID_LOGIN_CREDENTIALS: "الإيميل أو كلمة السر غلط", INVALID_PASSWORD: "كلمة السر غلط", EMAIL_NOT_FOUND: "مفيش حساب بالإيميل ده", WEAK_PASSWORD: "كلمة السر ضعيفة", INVALID_EMAIL: "الإيميل غير صحيح", TOO_MANY_ATTEMPTS_TRY_LATER: "محاولات كتير، جرّب بعد شوية" }[c] || "حصلت مشكلة، حاول تاني");
async function fbCall(path, body) {
  const r = await fetch("https://identitytoolkit.googleapis.com/v1/" + path + "?key=" + CFG.FIREBASE.apiKey, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
  const j = await r.json(); if (!r.ok) throw new Error(((j.error && j.error.message) || "").split(" ")[0]); return j;
}
async function doAuth(tab) {
  const em = $("#em").value.trim().toLowerCase(), pw = $("#pw").value, nm = tab === "up" ? $("#nm").value.trim() : "";
  const err = m => { $("#err").textContent = m; };
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(em)) return err("اكتب إيميل صحيح");
  if (pw.length < 6) return err("كلمة السر لازم 6 أحرف على الأقل");
  if (tab === "up" && nm.length < 2) return err("اكتب اسمك في اللعبة");
  const btn = $("#sub"); btn.disabled = true; err("");
  const accs = lsGet("fm_accounts", {}); const h = await sha(em + "|" + pw);
  try {
    if (firebaseOn() && online()) {
      const j = await fbCall(tab === "up" ? "accounts:signUp" : "accounts:signInWithPassword", { email: em, password: pw, returnSecureToken: true });
      const name = tab === "up" ? nm : (accs[em] && accs[em].name) || em.split("@")[0];
      accs[em] = { h, name, id: j.localId }; lsSet("fm_accounts", accs);
      return startSession({ id: j.localId, email: em, name });
    }
    if (firebaseOn() && !online() && tab === "up") { btn.disabled = false; return err("محتاج نت لإنشاء حساب جديد"); }
    if (tab === "up") {
      if (accs[em]) { btn.disabled = false; return err("الإيميل ده مسجل قبل كده"); }
      accs[em] = { h, name: nm, id: "u" + hashStr(em) }; lsSet("fm_accounts", accs);
      return startSession({ id: accs[em].id, email: em, name: nm });
    }
    if (!accs[em] || accs[em].h !== h) { btn.disabled = false; return err(accs[em] || !firebaseOn() ? "الإيميل أو كلمة السر غلط" : "سجّل دخولك أونلاين أول مرة"); }
    startSession({ id: accs[em].id, email: em, name: accs[em].name });
  } catch (e) { btn.disabled = false; err(authErr(e.message)); }
}
async function forgot() {
  const em = $("#em").value.trim();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(em)) return ($("#err").textContent = "اكتب إيميلك الأول");
  try { await fbCall("accounts:sendOobCode", { requestType: "PASSWORD_RESET", email: em }); toast("بعتنالك رسالة على الإيميل ✉"); }
  catch (e) { $("#err").textContent = authErr(e.message); }
}
function startSession(s) { SES = s; lsSet("fm_session", s); loadData(); save(); dailyLogin(); go("home"); }
function logout() { SES = null; S = null; try { localStorage.removeItem("fm_session"); } catch (e) {} go("login"); }

function dailyLogin() {
  if (S.daily.last === today()) return;
  S.daily.streak = S.daily.last === yesterday() ? S.daily.streak + 1 : 1;
  S.daily.last = today(); S.daily.claimedToday = false; save();
}

/* الرئيسية */
R.home = function () {
  const rows = LADDER.map((v, i) => i).reverse().map(i => {
    const cls = i === 14 ? "mil" : SAFE.includes(i) ? "safe" : "";
    return `<div class="r ${cls}"><span>${i === 14 ? "👑 " : ""}${String(i+1).padStart(2,"0")}</span><span>${fmt(LADDER[i])}${i===14?"":'<i></i>'}</span></div>`;
  }).join("");
  const n = [!S.daily.claimedToday ? "🎁" : ""].join("");
  app.innerHTML = header() + `
    <div class="hero">
      <div class="emb"><div class="tag">اختبر معرفتك.. وكن مليونيراً!</div><img src="icon.png" alt=""></div>
      <div class="ladder">${rows}</div>
    </div>
    <div class="ticker"><span>⚽</span><span>أسئلة كروية</span><span>•</span><span>تحدي المشجعين</span><span>•</span><span>هل أنت جاهز؟</span><span>⚽</span></div>
    <button class="btn big" id="play">▶ ابدأ اللعب</button>
    <div class="tiles">
      <button class="tile" data-go="stats"><div class="ic">📊</div><b>إحصائياتي</b><small>شوف مستواك</small></button>
      <button class="tile" data-go="rewards"><div class="ic">🎁</div><b>المكافآت ${n}</b><small>جوائز وهدايا</small></button>
      <button class="tile" data-go="helps"><div class="ic">💡</div><b>المساعدات</b><small>استخدمها بحكمة</small></button>
    </div>
    <div class="banner"><div class="ic">👑⚽</div><div>ليس فقط عن كرة القدم.. بل عن ذكائك وشغفك بها! <div style="margin-top:4px">${netBadge()}</div></div></div>
  ` + nav("home");
  $("#play").onclick = () => startGame("classic");
  fillCache();
};

/* الإحصائيات */
const ACH = [
  ["first", "🎯", "أول فوز", "أجب بشكل صحيح على سؤال", s => s.stats.correct >= 1],
  ["c50", "⚽", "عاشق الكرة", "50 إجابة صحيحة", s => s.stats.correct >= 50],
  ["c250", "🏅", "خبير الكرة", "250 إجابة صحيحة", s => s.stats.correct >= 250],
  ["st10", "🔥", "سلسلة نارية", "10 إجابات صحيحة متتالية", s => s.stats.bestStreak >= 10],
  ["g10", "🎮", "مدمن اللعب", "العب 10 مباريات", s => s.stats.games >= 10],
  ["mil", "👑", "المليونير", "اوصل لمليون", s => s.stats.millions >= 1]
];
function checkAch() { ACH.forEach(a => { if (!S.ach[a[0]] && a[4](S)) { S.ach[a[0]] = 1; S.gems += 50; toast("🏆 إنجاز جديد: " + a[2] + " (+50 💎)"); } }); }
R.stats = function () {
  const st = S.stats, tot = st.correct + st.wrong, acc = tot ? Math.round(st.correct / tot * 100) : 0;
  const next = RANKS.find(r => r[0] > S.points); const prev = [...RANKS].reverse().find(r => r[0] <= S.points);
  const pct = next ? Math.round((S.points - prev[0]) / (next[0] - prev[0]) * 100) : 100;
  app.innerHTML = header() + `<h2>📊 إحصائياتي</h2>
    <div class="card"><div class="row"><b class="grow">${rankOf(S.points)}</b><span class="pill">${num(S.points)} نقطة</span></div>
      <div class="bar" style="margin-top:10px"><i style="width:${pct}%"></i></div>
      <div class="mut" style="margin-top:6px">${next ? "الرتبة الجاية: " + next[1] + " عند " + num(next[0]) + " نقطة" : "وصلت لأعلى رتبة 👑"}</div></div>
    <div class="grid2">
      <div class="card stat"><b>${st.games}</b><small>مباريات</small></div>
      <div class="card stat"><b>${acc}%</b><small>نسبة الدقة</small></div>
      <div class="card stat"><b>${st.correct}</b><small>إجابات صحيحة</small></div>
      <div class="card stat"><b>${st.wrong}</b><small>إجابات خاطئة</small></div>
      <div class="card stat"><b>${st.best ? fmt(st.best) : "—"}</b><small>أعلى جائزة</small></div>
      <div class="card stat"><b>${st.bestStreak}</b><small>أطول سلسلة صح</small></div>
    </div>
    <h2>🏅 الإنجازات</h2><div class="card">${ACH.map(a => `<div class="ach ${S.ach[a[0]]?"on":""}"><span class="ic">${a[1]}</span><div><b>${a[2]}</b><div class="mut">${a[3]}</div></div></div>`).join("")}</div>
  ` + nav("profile");
};

/* المكافآت */
R.rewards = function () {
  const st = S.daily.streak, idx = (st - 1) % 7;
  const days = DAILY_GEMS.map((g, i) => `<div class="day ${i < idx || (i === idx && S.daily.claimedToday) ? "done" : ""} ${i === idx && !S.daily.claimedToday ? "now" : ""}">يوم ${i+1}<b>${g}</b>💎</div>`).join("");
  const m = S.mis;
  const mis = (key, need, gems, label) => {
    const ok = m.correct >= need, done = m[key];
    return `<div class="row" style="padding:8px 0"><div class="grow"><b>${label}</b><div class="mut">${Math.min(m.correct, need)} / ${need}</div><div class="bar" style="margin-top:4px"><i style="width:${Math.min(100, m.correct/need*100)}%"></i></div></div>
      <button class="btn ${done ? "ghost" : ""}" data-mis="${key}" style="width:auto;padding:8px 14px;font-size:14px" ${!ok || done ? "disabled" : ""}>${done ? "تم ✓" : "+" + gems + " 💎"}</button></div>`;
  };
  app.innerHTML = header() + `<h2>🎁 المكافآت</h2>
    <div class="card"><b>الهدية اليومية</b> <span class="pill">أيام متتالية: ${st}</span><div class="days">${days}</div>
      <button class="btn" id="claim" ${S.daily.claimedToday ? "disabled" : ""}>${S.daily.claimedToday ? "استلمت هدية النهاردة ✓" : "استلم +" + DAILY_GEMS[idx] + " 💎"}</button></div>
    <div class="card"><b>مهام اليوم</b>${mis("c10", 10, 60, "جاوب 10 أسئلة صح")}${mis("c25", 25, 150, "جاوب 25 سؤال صح")}</div>
    <p class="mut" style="text-align:center">اللعبة ترفيهية، والجوائز والأرباح افتراضية داخل اللعبة فقط.</p>
  ` + nav("home");
  $("#claim").onclick = () => { if (S.daily.claimedToday) return; S.gems += DAILY_GEMS[idx]; S.daily.claimedToday = true; save(); sfx.win(); toast("+" + DAILY_GEMS[idx] + " 💎"); R.rewards(); };
  app.querySelectorAll("[data-mis]").forEach(b => b.onclick = () => { const k = b.dataset.mis; const g = k === "c10" ? 60 : 150; if (S.mis[k]) return; S.mis[k] = true; S.gems += g; save(); sfx.win(); toast("+" + g + " 💎"); R.rewards(); });
};

/* المساعدات */
R.helps = function () {
  app.innerHTML = header() + `<h2>💡 المساعدات</h2>
    <p class="mut">في كل مباراة معاك مرة من كل مساعدة. تقدر تشتري زيادة بالجواهر 💎 وتحتفظ بيها.</p>` +
    Object.keys(LL).map(k => `<div class="chal"><div class="ic">${LL[k].ic}</div><div class="t grow"><b>${LL[k].nm}</b><small>${{fifty:"يشيل إجابتين غلط",aud:"الجمهور يصوّت على الإجابة",call:"صديقك يقترح إجابة (مش مضمونة)",skip:"تعدّي السؤال بدون ما تخسر"}[k]}</small><br><small>معاك زيادة: ${S.inv[k]}</small></div><button class="btn" data-buy="${k}">${LL[k].price} 💎</button></div>`).join("") + nav("home");
  app.querySelectorAll("[data-buy]").forEach(b => b.onclick = () => { const k = b.dataset.buy; if (S.gems < LL[k].price) return toast("جواهرك مش كفاية — خدها من المكافآت 🎁"); S.gems -= LL[k].price; S.inv[k]++; save(); sfx.ok(); R.helps(); });
};

/* نتائجي / المتصدرين */
R.board = function () {
  const h = S.hist.slice(0, 15);
  app.innerHTML = header() + `<h2>🏆 سجل نتائجي</h2>
    <div class="card"><div class="row"><div class="grow"><b>${esc(SES.name)}</b><div class="mut">${rankOf(S.points)}</div></div><span class="pill">${num(S.points)} نقطة</span></div></div>
    <div class="card lb">${h.length ? h.map((x, i) => `<div class="r"><span class="n">${i+1}</span><div class="grow"><b>${x.mode}</b><div class="mut">${x.date}</div></div><div style="text-align:left"><b style="color:var(--gold1)">+${num(x.pts)}</b><div class="mut">${x.info}</div></div></div>`).join("") : '<div class="mut" style="text-align:center;padding:16px">لسه ماعبتش أي مباراة — ابدأ دلوقتي!</div>'}</div>
    ${SES.guest ? '<p class="mut" style="text-align:center">سجّل بحساب لحفظ تقدّمك باسمك.</p>' : ""}` + nav("board");
};

/* الحساب */
R.profile = function () {
  app.innerHTML = header() + `<h2>👤 حسابي</h2>
    <div class="card"><div class="row"><div class="avatar">👑</div><div class="grow"><b>${esc(SES.name)}</b><div class="mut" dir="ltr" style="text-align:right">${esc(SES.email || "حساب ضيف")}</div><div class="mut">★ ${rankOf(S.points)}</div></div></div></div>
    <button class="btn sec" data-go="stats" style="margin-bottom:10px">📊 إحصائياتي والإنجازات</button>
    <button class="btn sec" data-go="rewards" style="margin-bottom:10px">🎁 المكافآت</button>
    <button class="btn sec" data-go="settings" style="margin-bottom:10px">⚙ الإعدادات</button>
    <button class="btn ghost" id="lo">${SES.guest ? "تسجيل حساب / دخول" : "تسجيل الخروج"}</button>` + nav("profile");
  $("#lo").onclick = logout;
};

/* الإعدادات */
R.settings = function () {
  const sw = (k, t) => `<div class="sw"><span>${t}</span><button class="tg ${S.set[k] ? "on" : ""}" data-sw="${k}"></button></div>`;
  app.innerHTML = header() + `<h2>⚙ الإعدادات</h2><div class="card">${sw("sound", "🔊 الصوت")}${sw("vibrate", "📳 الاهتزاز")}</div>
    <div class="card"><b>الأسئلة</b><div class="mut" style="margin:6px 0">${netBadge()} — ${online() ? (aiOn() ? "🤖 أسئلة جديدة بالذكاء الاصطناعي بدون تكرار" : "الأسئلة المدمجة") : "بتلعب بالأسئلة المحفوظة"}<br>محفوظ للعب بدون نت: ${CACHE.length} / ${CACHE_MAX} سؤال<br>صعوبتك الحالية: ${S.lvl} (بتزيد مع كل إجابة صح)</div>
      <button class="btn sec" id="upd">🔄 تحديث الأسئلة الآن</button></div>
    <div class="card mut">مليونير كرة القدم — لعبة ترفيهية. الجوائز افتراضية ولا توجد أي جوائز مالية حقيقية. الأسئلة عن كرة القدم للرجال.</div>` + nav("profile");
  app.querySelectorAll("[data-sw]").forEach(b => b.onclick = () => { S.set[b.dataset.sw] = !S.set[b.dataset.sw]; save(); R.settings(); });
  $("#upd").onclick = async () => { if (!online()) return toast("مفيش نت حالياً"); toast("جاري التحديث..."); aiDownUntil = 0; fillRuns = 0; const ok = await refreshQuestions(); fillCache(); toast(ok ? "تم تحديث الأسئلة ✓" : "بنجهّز أسئلة جديدة في الخلفية 🤖"); R.settings(); };
};

/* التحديات */
R.challenges = function () {
  const doneToday = S.dc === today();
  const c = (ic, t, d, id, extra, dis) => `<div class="chal"><div class="ic">${ic}</div><div class="t grow"><b>${t}</b><small>${d}</small></div><button class="btn" data-ch="${id}" ${dis ? "disabled" : ""}>${extra}</button></div>`;
  app.innerHTML = header() + `<h2>⚡ التحديات</h2>` +
    c("📅", "تحدي اليوم", "10 أسئلة — مرة كل يوم — 20 💎 لكل إجابة صح", "daily", doneToday ? "تم ✓" : "العب", doneToday) +
    c("⏱", "تحدي السرعة", "60 ثانية: جاوب أكبر عدد من الأسئلة", "speed", "العب") +
    c("🔥", "تحدي الصمود", "كمّل لحد أول غلطة — كل إجابة صح بنقاط أعلى", "survive", "العب") +
    c("👑", "المليونير الكلاسيكي", "15 سؤال والمساعدات الأربعة", "classic", "العب") + nav("challenges");
  app.querySelectorAll("[data-ch]").forEach(b => b.onclick = () => startGame(b.dataset.ch));
};


/* البطولات: بتصرف فيها الجواهر 💎 */
const CUPS = {
  wc:   { nm: "كأس العالم", ic: "🌍", fee: 150, per: 3, need: 2, stages: [["دور المجموعات", 40], ["دور الـ16", 80], ["ربع النهائي", 150], ["نصف النهائي", 250], ["النهائي", 500]] },
  ucl:  { nm: "دوري أبطال أوروبا", ic: "⭐", fee: 80, per: 3, need: 2, stages: [["دور المجموعات", 30], ["ربع النهائي", 70], ["نصف النهائي", 120], ["النهائي", 250]] },
  afcon:{ nm: "كأس الأمم الأفريقية", ic: "🦁", fee: 50, per: 3, need: 2, stages: [["دور المجموعات", 25], ["نصف النهائي", 60], ["النهائي", 140]] }
};
const stageD = (cup, i) => 2 + Math.round(i * 6 / (cup.stages.length - 1));
R.arena = function () {
  app.innerHTML = header() + `<h2>🌍 البطولات</h2>
    <p class="mut">ادفع جواهرك 💎 وادخل البطولة. في كل دور لازم تجاوب ${CUPS.wc.need} من ${CUPS.wc.per} صح عشان تعدّي — وكل إجابة صح بتخلّي السؤال الجاي أصعب. وكل دور تعدّيه بتاخد جواهر!</p>` +
    Object.keys(CUPS).map(k => { const c = CUPS[k], tot = c.stages.reduce((a, x) => a + x[1], 0);
      return `<div class="card"><div class="row"><div class="ic" style="font-size:34px">${c.ic}</div><div class="grow"><b>${c.nm}</b><div class="mut">${c.stages.length} أدوار • الجائزة الكاملة ${tot} 💎</div><div class="mut">${c.stages.map(x => x[0]).join(" ← ")}</div></div></div>
      <button class="btn" data-cup="${k}" style="margin-top:10px" ${S.gems < c.fee ? "disabled" : ""}>ادخل البطولة — ${c.fee} 💎</button></div>`; }).join("") +
    `<button class="btn sec" data-go="helps" style="margin:6px 0 10px">💡 اشترِ مساعدات بالجواهر</button>
    <p class="mut" style="text-align:center">الجواهر بتيجي من الهدية اليومية والمهام واللعب. 🎁</p>` + nav("arena");
  app.querySelectorAll("[data-cup]").forEach(b => b.onclick = () => {
    const c = CUPS[b.dataset.cup];
    modal(`<div class="big">${c.ic}</div><h3>${c.nm}</h3><p>رسوم الدخول ${c.fee} 💎. لو خرجت من البطولة بتحتفظ بالجواهر اللي كسبتها في الأدوار اللي عدّيتها.</p><button class="btn" id="y">ادفع وابدأ</button><button class="btn ghost" id="n">لأ</button>`);
    $("#y").onclick = () => { closeModal(); startGame("cup", b.dataset.cup); }; $("#n").onclick = closeModal;
  });
};

/* ---------- اللعب ---------- */
async function startGame(mode, cupId) {
  sfx.tap();
  if (!S) return;
  let cup = null;
  if (mode === "cup") {
    cup = CUPS[cupId];
    if (!cup || S.gems < cup.fee) return toast("جواهرك مش كفاية 💎");
    S.gems -= cup.fee; save();
  }
  if (online() && remoteConfigured() && !startGame.did) { startGame.did = 1; refreshQuestions(); }
  G = { mode, i: 0, q: null, usedIds: new Set(), locked: false, free: { fifty: 1, aud: 1, call: 1, skip: 1 }, score: 0, right: 0, wrong: 0, streak: 0, t: 0, over: false, hidden: [], maxD: 0 };
  if (mode === "speed") G.total = 60;
  if (cup) Object.assign(G, { cup, cupId, stage: 0, qi: 0, rs: 0, ws: 0, cupGems: 0, stD: stageD(cup, 0) });
  go("game");
}
const qTime = () => G.mode === "cup" ? 40 : G.i < 5 ? 30 : G.i < 10 ? 45 : 60;
const llCount = k => G.free[k] + S.inv[k];

R.game = async function () {
  if (!G) return go("home");
  const ref = G;
  if (!G.q) {
    stopTimer();
    app.innerHTML = `<div class="gtop"><button class="ibtn" id="quit">✕</button><div class="prize"><small>${online() ? "🤖 جاري تجهيز سؤال جديد" : "📴 أسئلة محفوظة"}</small><b>⏳</b></div><div class="timer">·</div></div><div class="qbox" style="text-align:center;margin-top:30px">بنجهّز لك السؤال...</div>`;
    $("#quit").onclick = confirmQuit;
    const q = await fetchQuestion(ref);
    if (G !== ref) return;
    if (!q) { G = null; toast("مفيش أسئلة متاحة حالياً"); return go("home"); }
    G.q = q;
  }
  renderQ();
};
function renderQ() {
  const q = G.q, m = G.mode;
  markServed(q); G.hidden = []; G.locked = false; prefetch(G.d);
  const classic = m === "classic", cup = m === "cup";
  const llHtml = (classic || m === "daily" || cup) ? '<div class="ll">' + Object.keys(LL).map(k => `<button data-ll="${k}" ${llCount(k) < 1 ? "disabled" : ""}><span>${LL[k].ic}</span>${LL[k].nm}<em>${llCount(k)}</em></button>`).join("") + "</div>" : "";
  const label = classic ? `السؤال <bdi>${G.i + 1} / 15</bdi>` : cup ? `${G.cup.stages[G.stage][0]} — <bdi>${G.qi + 1} / ${G.cup.per}</bdi>` : m === "daily" ? `السؤال <bdi>${G.i + 1} / 10</bdi>` : m === "speed" ? `صح: ${G.right}` : `سلسلة: ${G.right}`;
  const centre = classic ? `<small>الجائزة الحالية</small><b>${fmt(LADDER[G.i])}</b>` : cup ? `<small>${G.cup.nm}</small><b>${G.cupGems} 💎</b>` : m === "daily" ? `<small>الإجابات الصح</small><b>${G.right}</b>` : m === "speed" ? `<small>النقاط</small><b>${G.score}</b>` : `<small>النقاط</small><b>${num(G.score)}</b>`;
  const dots = `<span class="pill" style="margin-inline-start:6px">🔥 صعوبة ${G.d}/10</span>`;
  app.innerHTML = `<div class="gtop">
      <button class="ibtn" id="quit">✕</button>
      <div class="prize">${centre}</div>
      <div class="timer" id="tm">${m === "speed" ? G.total : qTime()}</div>
    </div>
    <span class="pill qn">${label}</span>${dots}
    <div class="qbox">${esc(q.q)}</div>
    ${llHtml}
    <div class="opts">${q.opts.map((o, i) => `<button class="opt" data-o="${i}"><b>${LET[i]}</b><span class="tx">${esc(o.t)}</span><span class="pc"></span></button>`).join("")}</div>
    ${classic ? '<div class="gfoot"><button class="btn ghost" id="wd">💰 انسحب بـ ' + (G.i ? fmt(LADDER[G.i-1]) : "0") + "</button></div>" : ""}`;
  app.querySelectorAll("[data-o]").forEach(b => b.onclick = () => answer(+b.dataset.o));
  app.querySelectorAll("[data-ll]").forEach(b => b.onclick = () => useLL(b.dataset.ll));
  $("#quit").onclick = () => confirmQuit();
  const wd = $("#wd"); if (wd) wd.onclick = () => { if (!G.i) return; modal(`<h3>تنسحب؟</h3><p>هتاخد ${fmt(LADDER[G.i-1])} وتنهي المباراة.</p><button class="btn" id="y">أيوه، انسحب</button><button class="btn ghost" id="n">كمّل اللعب</button>`); $("#y").onclick = () => { closeModal(); finish("withdraw"); }; $("#n").onclick = closeModal; };
  startQTimer();
}
function startQTimer() {
  stopTimer();
  const tm = $("#tm");
  if (G.mode === "speed") {
    timerId = setInterval(() => { G.total--; tm.textContent = G.total; tm.classList.toggle("low", G.total <= 10); if (G.total <= 10) sfx.tick(); if (G.total <= 0) { stopTimer(); finish("time"); } }, 1000);
  } else {
    G.t = qTime(); tm.textContent = G.t;
    timerId = setInterval(() => { G.t--; tm.textContent = G.t; tm.classList.toggle("low", G.t <= 8); if (G.t <= 5) sfx.tick(); if (G.t <= 0) { stopTimer(); answer(-1); } }, 1000);
  }
}
function confirmQuit() {
  modal(`<h3>خروج؟</h3><p>${G.mode === "classic" ? "لو خرجت دلوقتي هتخسر المباراة (من غير ما تاخد الجائزة)." : G.mode === "cup" ? "هتخسر رسوم الدخول، والجواهر اللي كسبتها في الأدوار اللي عدّيتها محفوظة." : "هيتحسب اللي حققته لحد دلوقتي."}</p><button class="btn" id="y">خروج</button><button class="btn ghost" id="n">كمّل</button>`);
  $("#y").onclick = () => { closeModal(); if (G.mode === "classic" && G.q) { G = null; go("home"); } else if (!G.q && G.mode === "classic") { G = null; go("home"); } else finish("quit"); };
  $("#n").onclick = closeModal;
}
function useLL(k) {
  if (G.locked || llCount(k) < 1) return;
  const q = G.q;
  if (G.free[k] > 0) G.free[k]--; else S.inv[k]--;
  save(); sfx.tap();
  if (k === "fifty") {
    const wrong = shuffle(q.opts.map((o, i) => i).filter(i => i !== q.ans)).slice(0, 2);
    wrong.forEach(i => { G.hidden.push(i); const b = app.querySelector(`[data-o="${i}"]`); if (b) b.classList.add("gone"); });
  } else if (k === "skip") {
    G.q = null; return R.game();
  } else if (k === "aud") {
    const strength = clamp(.8 - q.d * .05, .3, .78);
    let c = Math.round((strength + Math.random() * .15) * 100); c = Math.min(c, 90);
    const left = q.opts.map((o, i) => i).filter(i => i !== q.ans && !G.hidden.includes(i));
    let rest = 100 - c; const pc = {}; pc[q.ans] = c;
    left.forEach((i, idx) => { const v = idx === left.length - 1 ? rest : Math.round(Math.random() * rest * .7); pc[i] = v; rest -= v; });
    const shown = q.opts.map((o, i) => i).filter(i => !G.hidden.includes(i));
    modal(`<h3>👥 رأي الجمهور</h3>${shown.map(i => `<div class="pollrow"><b>${LET[i]}</b><div class="bar"><i style="width:${pc[i]||0}%"></i></div><span>${pc[i]||0}%</span></div>`).join("")}<button class="btn" id="ok">تمام</button>`);
    $("#ok").onclick = closeModal;
  } else if (k === "call") {
    const acc = clamp(.96 - q.d * .055, .4, .92);
    const pool = q.opts.map((o, i) => i).filter(i => !G.hidden.includes(i));
    const pick = Math.random() < acc ? q.ans : shuffle(pool.filter(i => i !== q.ans))[0];
    const sure = Math.random() < acc;
    modal(`<div class="big">📞</div><h3>صديقك بيقول:</h3><p>${sure ? "أنا متأكد تقريباً" : "مش متأكد أوي، بس أعتقد"} إن الإجابة <b style="color:var(--gold1)">(${LET[pick]}) ${esc(q.opts[pick].t)}</b></p><button class="btn" id="ok">شكراً</button>`);
    $("#ok").onclick = closeModal;
  }
  const bt = app.querySelector(`[data-ll="${k}"]`); if (bt) { bt.querySelector("em").textContent = llCount(k); if (llCount(k) < 1) bt.disabled = true; }
}
function answer(i) {
  if (G.locked) return; G.locked = true;
  if (G.mode !== "speed") stopTimer();
  const q = G.q, btns = app.querySelectorAll("[data-o]");
  btns.forEach(b => b.setAttribute("disabled", ""));
  const right = i === q.ans;
  if (i >= 0) btns[i].classList.add("sel");
  const delay = G.mode === "speed" ? 350 : 1100, ref = G;
  setTimeout(() => {
    if (G !== ref) return;
    if (i >= 0) btns[i].classList.remove("sel");
    btns[q.ans].classList.add("ok");
    if (i >= 0 && !right) btns[i].classList.add("no");
    right ? (sfx.ok(), vib(40)) : (sfx.no(), vib([80, 60, 120]));
    S.stats[right ? "correct" : "wrong"]++;
    if (right) { S.mis.correct++; G.right++; G.streak++; S.stats.streak = G.streak; S.stats.bestStreak = Math.max(S.stats.bestStreak, G.streak); G.score += G.mode === "survive" ? 50 * q.l + G.streak * 5 : G.mode === "speed" ? 100 + 20 * q.l : 0; }
    else { G.wrong++; G.streak = 0; S.stats.streak = 0; }
    save();
    setTimeout(() => { if (G === ref) next(right, i === -1); }, ref.mode === "speed" ? 450 : 1300);
  }, delay);
}
function nextQ() { G.q = null; R.game(); }
function next(right, timeout) {
  if (G.mode === "classic") {
    if (!right) return finish(timeout ? "timeout" : "wrong");
    if (G.i === 14) return finish("million");
    G.i++; return nextQ();
  }
  if (G.mode === "daily") { if (G.i >= 9) return finish("done"); G.i++; return nextQ(); }
  if (G.mode === "survive") { if (!right) return finish("wrong"); if (G.i >= 79) return finish("done"); G.i++; return nextQ(); }
  if (G.mode === "speed") { G.i++; return nextQ(); }
  if (G.mode === "cup") {
    right ? G.rs++ : G.ws++; G.qi++; G.i++;
    if (G.qi < G.cup.per) return nextQ();
    const st = G.cup.stages[G.stage];
    if (G.rs < G.cup.need) return finish("out");
    G.cupGems += st[1]; S.gems += st[1]; save();
    if (G.stage >= G.cup.stages.length - 1) return finish("champion");
    const done = st[0], nxtName = G.cup.stages[G.stage + 1][0];
    G.stage++; G.qi = 0; G.rs = 0; G.ws = 0; G.stD = stageD(G.cup, G.stage);
    sfx.win(); confetti();
    modal(`<div class="big">✅</div><h3>عدّيت ${done}!</h3><p>+${st[1]} 💎<br>الدور الجاي: <b style="color:var(--gold1)">${nxtName}</b> — الأسئلة أصعب</p><button class="btn" id="ok">كمّل</button>`);
    $("#ok").onclick = () => { closeModal(); nextQ(); };
  }
}

function finish(why) {
  stopTimer();
  const g = G; G = null; if (!g) return go("home");
  let prize = 0, pts = 0, gems = 0, title = "", icon = "⚽", msg = "", info = "";
  const name = g.mode === "cup" ? g.cup.nm : { classic: "المليونير الكلاسيكي", daily: "تحدي اليوم", speed: "تحدي السرعة", survive: "تحدي الصمود" }[g.mode];
  let shownGems = null;
  if (g.mode === "classic") {
    if (why === "million") { prize = 1000000; S.stats.millions++; }
    else if (why === "withdraw") prize = g.i ? LADDER[g.i - 1] : 0;
    else { const s = [...SAFE].reverse().find(x => g.i > x); prize = s !== undefined ? LADDER[s] : 0; }
    pts = prize; gems = Math.round(prize / 400) + (why === "million" ? 500 : 0);
    S.stats.best = Math.max(S.stats.best, prize);
    info = fmt(prize);
    if (why === "million") { icon = "👑"; title = "مبروك! أنت مليونير كرة القدم!"; msg = "جاوبت على كل الأسئلة الـ15 صح 🎉"; }
    else if (why === "withdraw") { icon = "💰"; title = "انسحاب ذكي"; msg = `خدت ${fmt(prize)}`; }
    else { icon = why === "timeout" ? "⏰" : "😢"; title = why === "timeout" ? "خلص الوقت!" : "إجابة غلط!"; msg = `الإجابة الصح: <b style="color:var(--gold1)">${esc(g.q.opts[g.q.ans].t)}</b><br>جايزتك: ${prize ? fmt(prize) : "0"}`; }
  } else if (g.mode === "cup") {
    pts = g.cupGems * 4; gems = 0; shownGems = g.cupGems; info = g.cupGems + " 💎";
    if (why === "champion") { icon = "🏆"; title = "بطل " + g.cup.nm + "!"; msg = "عدّيت كل الأدوار وكسبت " + g.cupGems + " 💎"; }
    else if (why === "out") { icon = "😢"; title = "خرجت من البطولة"; msg = `ودّعت في ${g.cup.stages[g.stage][0]}<br>كسبت ${g.cupGems} 💎 من الأدوار اللي عدّيتها`; }
    else { icon = "🚪"; title = "انسحبت من البطولة"; msg = `محفوظ لك ${g.cupGems} 💎`; }
  } else if (g.mode === "daily") {
    S.dc = today(); S.stats.dailyDone++; pts = g.right * 50; gems = g.right * 20; info = g.right + "/10";
    icon = g.right >= 7 ? "🏆" : "👏"; title = "خلصت تحدي اليوم"; msg = `جاوبت ${g.right} من 10`;
  } else if (g.mode === "speed") {
    pts = g.score; gems = Math.floor(g.right / 2) * 5; info = g.right + " صح"; icon = "⏱"; title = "انتهى الوقت!"; msg = `جاوبت ${g.right} إجابة صح`;
  } else {
    pts = g.score; gems = Math.floor(g.right / 3) * 5; info = g.right + " صح"; icon = "🔥"; title = why === "done" ? "ما غلطتش ولا مرة!" : "غلطة وخلصت"; msg = `سلسلتك: ${g.right} إجابة صح`;
  }
  S.stats.games++; S.points += pts; S.gems += gems;
  S.lvl = g.right >= 3 ? clamp(Math.round(g.maxD / 2.5), S.lvl, 4) : clamp(S.lvl - (g.wrong > g.right ? 1 : 0), 1, 4);
  S.hist.unshift({ mode: name, date: new Date().toLocaleDateString("ar-EG"), pts, info }); S.hist = S.hist.slice(0, 30);
  checkAch(); save();
  const win = pts > 0 && why !== "wrong" && why !== "timeout" && why !== "out";
  (why === "million" || why === "champion" ? sfx.win() : win ? sfx.ok() : sfx.no()); if (why === "million" || why === "champion" || (win && g.mode !== "classic" && g.mode !== "cup")) confetti();
  screen = "result"; window.scrollTo(0, 0);
  app.innerHTML = `<div style="text-align:center;padding-top:40px"><div style="font-size:72px">${icon}</div><h2 style="font-size:26px">${title}</h2><p style="line-height:1.8">${msg}</p>
    <div class="grid2" style="margin:18px 0"><div class="card stat"><b>+${num(pts)}</b><small>نقاط</small></div><div class="card stat"><b>+${num(shownGems == null ? gems : shownGems)} 💎</b><small>جواهر</small></div></div>
    <button class="btn" id="again">🔁 العب تاني</button><button class="btn sec" id="hm" style="margin-top:10px">🏠 الرئيسية</button></div>`;
  $("#again").onclick = () => g.mode === "daily" ? go("challenges") : g.mode === "cup" ? go("arena") : startGame(g.mode);
  $("#hm").onclick = () => go("home");
}

/* ---------- ربط الأحداث ---------- */
document.addEventListener("click", e => {
  const g = e.target.closest("[data-go]");
  if (g && !g.closest(".modal")) { if (G && screen === "game") return; sfx.tap(); go(g.dataset.go); }
});
const onBack = () => { if (!$("#modal").classList.contains("hidden")) closeModal(); else if (screen === "game" && G) confirmQuit(); else if (screen !== "home" && screen !== "login" && SES) go("home"); else if (window.Capacitor && Capacitor.Plugins && Capacitor.Plugins.App) Capacitor.Plugins.App.exitApp(); };
try { if (window.Capacitor && Capacitor.Plugins && Capacitor.Plugins.App) Capacitor.Plugins.App.addListener("backButton", onBack); } catch (e) {}
window.addEventListener("online", () => { aiDownUntil = 0; refreshQuestions(); fillCache(); toast("رجع النت 🌐 — أسئلة جديدة"); if (screen === "home") R.home(); });
window.addEventListener("offline", () => { toast("النت قطع — هتكمل بأسئلة محفوظة 📴"); });

padCache();
go("splash");
})();
